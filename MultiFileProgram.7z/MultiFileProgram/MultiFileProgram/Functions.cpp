#include "pch.h"
#include <iostream>
#include <string>
#include "Header.h"

int add(int x, int y) {
	return x + y;
}

int getInteger() {
	std::cout << "Give an integer: ";
	int x{ 0 };
	std::cin >> x;
	return x;
}