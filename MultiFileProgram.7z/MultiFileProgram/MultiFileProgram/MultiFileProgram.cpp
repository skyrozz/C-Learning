#include "pch.h"
#include <iostream>
#include <string>
#include "Header.h"


/* Lets Keep this file only for the main function and create a second file for every function that we make.
*/

//Because our functions are in a different file, the compiler doesnt know what for example the function add is. 
//This is why we have to use forward declaration in order for our program to compile and work.
//int add(int x, int y);
//int getInteger();
// forward declaring all your functions like this gets tedious really quick. using header file(s) we can fix this problem.


int main()
{
	std::cout << "The sum of 3 and 4 is: " << add(3, 4) << "\n";

	int x = getInteger();
	int y = getInteger();

	std::cout << x << " + " << y << " is " << x + y << "\n";

	return 0;
}