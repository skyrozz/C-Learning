#pragma once //Many compilers support a simpler, alternate form of header guards using the #pragma directive.
// #pragma once serves the same purpose as header guards, and has the added benefit of being shorter and less error-prone.
//For compatibility purposes, we recommend sticking to traditional header guards.
//They aren�t much more work and they�re guaranteed to be supported on all compliant compilers.

/* Header guards

The good news is that we can avoid the above problem via a mechanism called a header guard (also called an include guard).
Header guards are conditional compilation directives that take the following form:

#ifndef SOME_UNIQUE_NAME_HERE
#define SOME_UNIQUE_NAME_HERE

// your declarations (and certain types of definitions) here

#endif

When this header is #included, the preprocessor check whether SOME_UNIQUE_NAME_HERE has been previously defined.
If this is the first time we�ve included the header, SOME_UNIQUE_NAME_HERE will not have been defined.
Consequently, it #defines SOME_UNIQUE_NAME_HERE and includes the contents of the file.
If the header is included again into the same file,
SOME_UNIQUE_NAME_HERE will already have been defined from the first time the contents of the header were included,
and the contents of the header will be ignored (thanks to the #ifndef).

All of your header files should have header guards on them. SOME_UNIQUE_NAME_HERE can be any name you want,
but by convention is set to the full filename of the header file, typed in all caps, using underscores for spaces or punctuation.
*/

//lets write a Header Guard for the functions of this program:

#ifndef FUNCTIONS
#define FUNCTIONS

int add(int x, int y);

int  getInteger();

#endif



/*
Header file best practices

Here are a few more recommendations for creating and using header files.

	- Always include header guards (we�ll cover these next lesson).
	- Do not define variables and functions in header files (global constants are an exception -- we�ll cover these later)
	- Give your header files the same name as the source files they�re associated with (e.g. grades.h is paired with grades.cpp).
	- Each header file should have a specific job, and be as independent as possible. For example, you might put all your declarations related to functionality A in A.h and all your declarations related to functionality B in B.h. That way if you only care about A later, you can just include A.h and not get any of the stuff related to B.
	- Be mindful of which headers you need to explicitly include for the functionality that you are using in your code files
	- Every header you write should compile on its own (it should #include every dependency it needs)
	- Only #include what you need (don�t include everything just because you can).
	- Do not #include .cpp files.
	- Order your #includes as follow: your own user-defined headers first, then 3rd party library headers, then standard library headers. This is a minor one, but may help highlight a user-defined header file that doesn�t directly #include everything it needs.

*/