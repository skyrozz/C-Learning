

#include "pch.h"
#include <iostream>
#include <string>
#include <stdio.h>
using namespace std;


/*Lets do some forward declaration:
//A forward declaration allows us to tell the compiler about the existence of an identifier before actually defining the identifier.
//To write a forward declaration for a function, we use a declaration statement called a function prototype.
//The function prototype consists of the function�s return type, name, parameters, but no function body
(the curly braces and everything in between them), terminated with a semicolon.
*/

void add(int x, int y); // function prototype includes return type, name, parameters, and semicolon.  No function body!
// so now the program will compile without giving errors even if we call the function "add" before  we have defined what said function does.
//you dont have  to specify the names of the parameters when using a function prototype. the following prototype would work just as fine:
// int add(int, int);

int getValueFromUser() {

	// use void as the return type when you dont want the function to return anything.

	/* When you write a user-defined function, 
	you get to determine whether your function will return a value back to the caller or not. 
	*/
	
	cout << "Enter an integer: ";
	int input{ 0 };
	cin >> input;

	//we use a return statement to return a wanted value back to the caller function (main this time)	
	return input; 
}

void sum(int x, int y) {
	//This function simply sums up two numbers given to it
	cout << x << " + " << y << " = " << x + y << "\n";
}

int doubleNumber(int number) {
	//Here we can take an integer and double it.
	return number * 2;
}

void add(int x, int y) { // I just created this function so that my forward declaration example would work.
	cout << x << " + " << y << " = " << x + y << "\n";
}


int main()
{
   /*
	cout << "Hello World!\n"; 
	cout << "bla bla bla" << endl ;
	 
	string name = "Juho" ;
	int age = 20;

	cout << "Hi my name is " << name << " and im " << age << " years old." << endl;

	for (int i = 0; i <= 3; i++) {
		cout << i << endl;
	}

	int a = 5; // copy initialization of value 5 into variable width
	int b(5); // direct initialization of value 5 into variable width
	/*
	   /* For simple data types (like integers), copy and direct initialization are essentially the same.
	   But for some advanced types, direct initialization can perform better than copy initialization. 
	   Prior to C++11, direct initialization was recommended over copy initialization in most cases because of the performance boost.
	   */
	  
	   // Prefer �\n� over std::endl when outputting text to the console. (i think it uses less memory)

	// to read user input from console, use std::cin
	/*
	string input;
	cout << "Please type something:";
	cin >> input;	// note that when taking input you use >> instead of << !
	cout << "you typed: " << input << endl ; // for some reason this only saved a string untill i pressed space :/
	// getline(cin, str); seems to do what i want. */

	/*

	int numberToDouble;
	cout << "Enter a number: ";
	cin >> numberToDouble;
	numberToDouble = numberToDouble * 2;
	cout << "the number you entered times 2 is: " << numberToDouble << endl;

	// lets optimize the number doubling bit...

	int number{ 0 };

	cout << "Please enter an integer: ";
	cin >> number;
	cout << "Double that number is: " << number * 2 << "\n";

	

	int firstNumber{ 0 };
	int secondNumber{ 0 };

	cout << "enter an integer: ";
	cin >> firstNumber;
	cout << "enter a second integer: ";
	cin >> secondNumber;
	cout << firstNumber << " + " << secondNumber << " is " << firstNumber + secondNumber << "\n";
	cout << firstNumber << " - " << secondNumber << " is " << firstNumber - secondNumber << "\n";
	*
	/*
	int number{ getValueFromUser() }; // Asking user for input and  saving the return value as an integer called number.

	cout << number << " doubled is: " << number * 2 << "\n";
	*/
	
	// Lets use the getValueFromUser function to do some basic math.
	
	/*int x{ getValueFromUser() }; //Lets get the first value of our math problem
	int y{ getValueFromUser() }; //Now we get the second value of the problem

	sum(x, y);
	*/
	// /\ optimized is:

	//sum(getValueFromUser(), getValueFromUser());
	//Now, we�re using the return value of function getValueFromUser
	//directly as an argument to function sum.

	/* In the following piece of code:
	someFunction(a(), b());
	a() or b() may be called first
	If the architectures evaluates left to right, a() will be called before b().
	If the architecture evaluates right to left, b() will be called before a().
	This may or not be of consequence, depending on what a() and b() do.
	If it is important that one argument evaluate first,
	you should explicitly define the order of execution, like so:
	int a{ a() }; // a() will always be called first
	int b{ b() }; // b() will always be called second
	someFunction(a, b); // it doesn't matter whether a or b are copied first because they are just values
	*/

	int num = getValueFromUser();
	int doubled = doubleNumber(num);

	cout << num << " doubled is: " << doubled << "\n";

	cout << "Juho on kakkapaa. \n";
	


	return 0;
}  