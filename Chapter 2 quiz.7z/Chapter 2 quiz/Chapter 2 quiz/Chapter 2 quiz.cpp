

#include "pch.h"
#include <iostream>
#include "io.h"


int main()
{
	writeAnswer(readNumber() + readNumber());

	return 0;
}