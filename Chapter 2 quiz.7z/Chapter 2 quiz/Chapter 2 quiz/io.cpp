#include "pch.h"
#include <iostream>
#include "io.h"


int readNumber() {
	int input{ 0 };
	std::cout << "Enter an integer: ";
	std::cin >> input;
	return input;
}

void writeAnswer(int answer) {
	std::cout << "The answer is: " << answer << "\n";
}
