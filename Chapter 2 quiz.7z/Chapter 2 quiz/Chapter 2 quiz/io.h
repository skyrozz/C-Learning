#pragma once

#ifndef FUNCTIONS
#define FUNCTIONS
int readNumber();

void writeAnswer(int answer);

#endif
