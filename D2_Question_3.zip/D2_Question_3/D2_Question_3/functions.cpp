#include "functions.hpp"
#include <iostream>

double getNumber(){
    double number{ 0 };
    std::cin >> number;
    return number;
}

char getSymbol(){
    char symbol;
    std::cin >> symbol;
    return symbol;
}

void printAnswer(double x, char symbol, double y){
    //std::cout << x << " " << symbol << " " << y << " is " << x symbol y;
    
    if (symbol == '+'){
        std::cout << x << " " << symbol << " " << y << " is " << x + y << "\n";
    }
    else if (symbol == '-'){
        std::cout << x << " " << symbol << " " << y << " is " << x - y << "\n";
    }
    else if (symbol == '*'){
        std::cout << x << " " << symbol << " " << y << " is " << x * y << "\n";
    }
    else if (symbol == '/'){
        std::cout << x << " " << symbol << " " << y << " is " << x / y << "\n";
    }
    else {
        std::cout << "You entered an invalid character";
    }
}
