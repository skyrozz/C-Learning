
#ifndef functions_hpp
#define functions_hpp

#include <stdio.h>
#include <iostream>

double getNumber();
char getSymbol();
void printAnswer(double x, char symbol, double y);
#endif
