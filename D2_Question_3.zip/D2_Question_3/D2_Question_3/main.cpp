#include "functions.hpp"
#include <iostream>

int main(int argc, const char * argv[]) {
    
    // 1. User is asked to enter 2 floating point numbers (use doubles)
    // 2. User is asked to enter one of the following mathematical symbols: +, -, *, /.
    // 3. Program computes the answer based on the users input and prints the input.
    // 4. If the user was to enter an invalid symbol, the program should print nothing.
    
    std::cout << "Enter a double value: ";
    double numberOne {getNumber()};
    std::cout << "Enter a double value: ";
    double numberTwo {getNumber()};
    //testing if function getNumber works how intended.
    //std::cout << numberOne << " " << numberTwo << "\n"; //so far so good
    //char mathematicalSymbol {getSymbol()};
    // Testing wether getSymbol(); works or not.
    std::cout << "Enter one of the following: +, -, * or /: ";
    char mathematicalSymbol {getSymbol()};
    //std::cout << mathematicalSymbol << "\n"; // So far So good!
    printAnswer(numberOne, mathematicalSymbol, numberTwo);
    
    return 0;
}
